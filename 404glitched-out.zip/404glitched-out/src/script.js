//got the idea from 2 other pens around here. 

// https://codepen.io/codetrail/pen/uHvpl
// https://codepen.io/kaypooma/pen/ehfjC