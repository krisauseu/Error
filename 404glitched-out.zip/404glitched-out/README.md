# 404 - Glitched out

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZonFire99/pen/EaYmGV](https://codepen.io/ZonFire99/pen/EaYmGV).

Got the idea from 2 other pens around here. 
I just threw in my own sense style.
http://codepen.io/codetrail/pen/uHvpl
http://codepen.io/kaypooma/pen/ehfjC

**Disclaimer: I am not responsible for your seizures**

Happy Coding! :)